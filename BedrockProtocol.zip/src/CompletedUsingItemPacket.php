<?php

/*
 * This file is part of BedrockProtocol.
 * Copyright (C) 2014-2022 PocketMine Team <https://github.com/pmmp/BedrockProtocol>
 *
 * BedrockProtocol is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

declare(strict_types=1);

namespace pocketmine\network\mcpe\protocol;

use pmmp\encoding\ByteBufferReader;
use pmmp\encoding\ByteBufferWriter;
use pmmp\encoding\LE;

class CompletedUsingItemPacket extends DataPacket implements ClientboundPacket{
	public const NETWORK_ID = ProtocolInfo::COMPLETED_USING_ITEM_PACKET;

	public const ACTION_UNKNOWN = -1;
	public const ACTION_EQUIP_ARMOR = 0;
	public const ACTION_EAT = 1;
	public const ACTION_ATTACK = 2;
	public const ACTION_CONSUME = 3;
	public const ACTION_THROW = 4;
	public const ACTION_SHOOT = 5;
	public const ACTION_PLACE = 6;
	public const ACTION_FILL_BOTTLE = 7;
	public const ACTION_FILL_BUCKET = 8;
	public const ACTION_POUR_BUCKET = 9;
	public const ACTION_USE_TOOL = 10;
	public const ACTION_INTERACT = 11;
	public const ACTION_RETRIEVED = 12;
	public const ACTION_DYED = 13;
	public const ACTION_TRADED = 14;
	public const ACTION_BRUSHING_COMPLETED = 15;

	public int $itemId;
	public int $action;

	/**
	 * @generate-create-func
	 */
	public static function create(int $itemId, int $action) : self{
		$result = new self;
		$result->itemId = $itemId;
		$result->action = $action;
		return $result;
	}

	public function decodePayload(ByteBufferReader $in, int $protocolId) : void{
		$this->itemId = LE::readSignedShort($in);
		$this->action = LE::readSignedInt($in);
	}

	public function encodePayload(ByteBufferWriter $out, int $protocolId) : void{
		LE::writeSignedShort($out, $this->itemId);
		LE::writeSignedInt($out, $this->action);
	}

	public function handle(PacketHandlerInterface $handler) : bool{
		return $handler->handleCompletedUsingItem($this);
	}
}
