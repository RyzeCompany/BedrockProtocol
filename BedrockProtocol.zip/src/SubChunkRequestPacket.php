<?php

/*
 * This file is part of BedrockProtocol.
 * Copyright (C) 2014-2022 PocketMine Team <https://github.com/pmmp/BedrockProtocol>
 *
 * BedrockProtocol is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

declare(strict_types=1);

namespace pocketmine\network\mcpe\protocol;

use pmmp\encoding\ByteBufferReader;
use pmmp\encoding\ByteBufferWriter;
use pmmp\encoding\LE;
use pmmp\encoding\VarInt;
use pocketmine\network\mcpe\protocol\types\SubChunkPosition;
use pocketmine\network\mcpe\protocol\types\SubChunkPositionOffset;
use function count;

class SubChunkRequestPacket extends DataPacket implements ServerboundPacket{
	public const NETWORK_ID = ProtocolInfo::SUB_CHUNK_REQUEST_PACKET;

	private int $dimension;
	private SubChunkPosition $basePosition;
	/**
	 * @var SubChunkPositionOffset[]
	 * @phpstan-var list<SubChunkPositionOffset>
	 */
	private array $entries;

	/**
	 * @generate-create-func
	 * @param SubChunkPositionOffset[] $entries
	 * @phpstan-param list<SubChunkPositionOffset> $entries
	 */
	public static function create(int $dimension, SubChunkPosition $basePosition, array $entries) : self{
		$result = new self;
		$result->dimension = $dimension;
		$result->basePosition = $basePosition;
		$result->entries = $entries;
		return $result;
	}

	public function getDimension() : int{ return $this->dimension; }

	public function getBasePosition() : SubChunkPosition{ return $this->basePosition; }

	/**
	 * @return SubChunkPositionOffset[]
	 * @phpstan-return list<SubChunkPositionOffset>
	 */
	public function getEntries() : array{ return $this->entries; }

	protected function decodePayload(ByteBufferReader $in, int $protocolId) : void{
		$this->dimension = VarInt::readSignedInt($in);
		if($protocolId <= ProtocolInfo::PROTOCOL_1_26_20){
			$this->basePosition = SubChunkPosition::readVarInts($in);
		}

		$this->entries = [];
		for($i = 0, $count = $protocolId >= ProtocolInfo::PROTOCOL_1_26_30 ? VarInt::readUnsignedInt($in) : LE::readUnsignedInt($in); $i < $count; $i++){
			$this->entries[] = SubChunkPositionOffset::read($in);
		}

		if($protocolId >= ProtocolInfo::PROTOCOL_1_26_30){
			$this->basePosition = SubChunkPosition::readFixedInts($in);
		}
	}

	protected function encodePayload(ByteBufferWriter $out, int $protocolId) : void{
		VarInt::writeSignedInt($out, $this->dimension);
		if($protocolId <= ProtocolInfo::PROTOCOL_1_26_20){
			$this->basePosition->writeVarInts($out);
		}

		if($protocolId >= ProtocolInfo::PROTOCOL_1_26_40){
			VarInt::writeUnsignedInt($out, count($this->entries));
		}elseif($protocolId >= ProtocolInfo::PROTOCOL_1_26_30){
			LE::writeUnsignedInt($out, count($this->entries));
		}else{
			VarInt::writeUnsignedInt($out, count($this->entries));
		}
		foreach($this->entries as $entry){
			$entry->write($out);
		}

		if($protocolId >= ProtocolInfo::PROTOCOL_1_26_30){
			$this->basePosition->writeFixedInts($out);
		}
	}

	public function handle(PacketHandlerInterface $handler) : bool{
		return $handler->handleSubChunkRequest($this);
	}
}
