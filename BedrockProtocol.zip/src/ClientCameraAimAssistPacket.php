<?php

/*
 * This file is part of BedrockProtocol.
 * Copyright (C) 2014-2022 PocketMine Team <https://github.com/pmmp/BedrockProtocol>
 *
 * BedrockProtocol is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

declare(strict_types=1);

namespace pocketmine\network\mcpe\protocol;

use pmmp\encoding\Byte;
use pmmp\encoding\ByteBufferReader;
use pmmp\encoding\ByteBufferWriter;
use pocketmine\network\mcpe\protocol\serializer\CommonTypes;
use pocketmine\network\mcpe\protocol\types\camera\CameraAimAssistActionType;

class ClientCameraAimAssistPacket extends DataPacket implements ServerboundPacket{
	public const NETWORK_ID = ProtocolInfo::CLIENT_CAMERA_AIM_ASSIST_PACKET;

	private string $presetId;
	private CameraAimAssistActionType $actionType;
	private bool $allowAimAssist;

	/**
	 * @generate-create-func
	 */
	public static function create(string $presetId, CameraAimAssistActionType $actionType, bool $allowAimAssist) : self{
		$result = new self;
		$result->presetId = $presetId;
		$result->actionType = $actionType;
		$result->allowAimAssist = $allowAimAssist;
		return $result;
	}

	public function getPresetId() : string{ return $this->presetId; }

	public function getActionType() : CameraAimAssistActionType{ return $this->actionType; }

	public function getAllowAimAssist() : bool{ return $this->allowAimAssist; }

	protected function decodePayload(ByteBufferReader $in, int $protocolId) : void{
		$this->presetId = CommonTypes::getString($in);
		$this->actionType = CameraAimAssistActionType::fromPacket(Byte::readUnsigned($in));
		$this->allowAimAssist = CommonTypes::getBool($in);
	}

	protected function encodePayload(ByteBufferWriter $out, int $protocolId) : void{
		CommonTypes::putString($out, $this->presetId);
		Byte::writeUnsigned($out, $this->actionType->value);
		CommonTypes::putBool($out, $this->allowAimAssist);
	}

	public function handle(PacketHandlerInterface $handler) : bool{
		return $handler->handleClientCameraAimAssist($this);
	}
}
