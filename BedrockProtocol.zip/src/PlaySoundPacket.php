<?php

/*
 * This file is part of BedrockProtocol.
 * Copyright (C) 2014-2022 PocketMine Team <https://github.com/pmmp/BedrockProtocol>
 *
 * BedrockProtocol is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

declare(strict_types=1);

namespace pocketmine\network\mcpe\protocol;

use pmmp\encoding\ByteBufferReader;
use pmmp\encoding\ByteBufferWriter;
use pmmp\encoding\LE;
use pmmp\encoding\VarInt;
use pocketmine\network\mcpe\protocol\serializer\CommonTypes;
use pocketmine\network\mcpe\protocol\types\BlockPosition;

class PlaySoundPacket extends DataPacket implements ClientboundPacket{
	public const NETWORK_ID = ProtocolInfo::PLAY_SOUND_PACKET;

	public string $soundName;
	public float $x;
	public float $y;
	public float $z;
	public float $volume;
	public float $pitch;
	public int $loopCount = 0;
	public ?int $serverSoundHandle = null;
	public bool $bypassListenerRangeCheck = false;
	public ?float $playbackPositionSeconds = null;

	/**
	 * @generate-create-func
	 */
	public static function create(
		string $soundName,
		float $x,
		float $y,
		float $z,
		float $volume,
		float $pitch,
		?int $serverSoundHandle,
		int $loopCount = 0,
		bool $bypassListenerRangeCheck = false,
		?float $playbackPositionSeconds = null,
	) : self{
		$result = new self;
		$result->soundName = $soundName;
		$result->x = $x;
		$result->y = $y;
		$result->z = $z;
		$result->volume = $volume;
		$result->pitch = $pitch;
		$result->serverSoundHandle = $serverSoundHandle;
		$result->loopCount = $loopCount;
		$result->bypassListenerRangeCheck = $bypassListenerRangeCheck;
		$result->playbackPositionSeconds = $playbackPositionSeconds;
		return $result;
	}

	protected function decodePayload(ByteBufferReader $in, int $protocolId) : void{
		$this->soundName = CommonTypes::getString($in);
		$blockPosition = CommonTypes::getBlockPosition($in, $protocolId >= ProtocolInfo::PROTOCOL_1_26_10);
		$this->x = $blockPosition->getX() / 8;
		$this->y = $blockPosition->getY() / 8;
		$this->z = $blockPosition->getZ() / 8;
		$this->volume = LE::readFloat($in);
		$this->pitch = LE::readFloat($in);
		if($protocolId >= ProtocolInfo::PROTOCOL_1_26_40){
			$this->loopCount = VarInt::readSignedInt($in);
		}
		if($protocolId >= ProtocolInfo::PROTOCOL_1_26_50){
			$this->bypassListenerRangeCheck = CommonTypes::getBool($in);
		}
		if($protocolId >= ProtocolInfo::PROTOCOL_1_26_20){
			$this->serverSoundHandle = CommonTypes::readOptional($in, LE::readUnsignedLong(...));
		}
		if($protocolId >= ProtocolInfo::PROTOCOL_1_26_50){
			$this->playbackPositionSeconds = CommonTypes::readOptional($in, LE::readFloat(...));
		}
	}

	protected function encodePayload(ByteBufferWriter $out, int $protocolId) : void{
		CommonTypes::putString($out, $this->soundName);
		CommonTypes::putBlockPosition($out, new BlockPosition((int) ($this->x * 8), (int) ($this->y * 8), (int) ($this->z * 8)), $protocolId >= ProtocolInfo::PROTOCOL_1_26_10);
		LE::writeFloat($out, $this->volume);
		LE::writeFloat($out, $this->pitch);
		if($protocolId >= ProtocolInfo::PROTOCOL_1_26_40){
			VarInt::writeSignedInt($out, $this->loopCount);
		}
		if($protocolId >= ProtocolInfo::PROTOCOL_1_26_50){
			CommonTypes::putBool($out, $this->bypassListenerRangeCheck);
		}
		if($protocolId >= ProtocolInfo::PROTOCOL_1_26_20){
			CommonTypes::writeOptional($out, $this->serverSoundHandle, LE::writeUnsignedLong(...));
		}
		if($protocolId >= ProtocolInfo::PROTOCOL_1_26_50){
			CommonTypes::writeOptional($out, $this->playbackPositionSeconds, LE::writeFloat(...));
		}
	}

	public function handle(PacketHandlerInterface $handler) : bool{
		return $handler->handlePlaySound($this);
	}
}
