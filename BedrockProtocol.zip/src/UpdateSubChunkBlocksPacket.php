<?php

/*
 * This file is part of BedrockProtocol.
 * Copyright (C) 2014-2022 PocketMine Team <https://github.com/pmmp/BedrockProtocol>
 *
 * BedrockProtocol is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

declare(strict_types=1);

namespace pocketmine\network\mcpe\protocol;

use pmmp\encoding\ByteBufferReader;
use pmmp\encoding\ByteBufferWriter;
use pmmp\encoding\VarInt;
use pocketmine\network\mcpe\protocol\serializer\CommonTypes;
use pocketmine\network\mcpe\protocol\types\BlockPosition;
use pocketmine\network\mcpe\protocol\types\UpdateSubChunkBlocksPacketEntry;
use function count;

class UpdateSubChunkBlocksPacket extends DataPacket implements ClientboundPacket{
	public const NETWORK_ID = ProtocolInfo::UPDATE_SUB_CHUNK_BLOCKS_PACKET;

	private BlockPosition $baseBlockPosition;

	/** @var UpdateSubChunkBlocksPacketEntry[] */
	private array $layer0Updates;
	/** @var UpdateSubChunkBlocksPacketEntry[] */
	private array $layer1Updates;

	/**
	 * @generate-create-func
	 * @param UpdateSubChunkBlocksPacketEntry[] $layer0Updates
	 * @param UpdateSubChunkBlocksPacketEntry[] $layer1Updates
	 */
	public static function create(BlockPosition $baseBlockPosition, array $layer0Updates, array $layer1Updates) : self{
		$result = new self;
		$result->baseBlockPosition = $baseBlockPosition;
		$result->layer0Updates = $layer0Updates;
		$result->layer1Updates = $layer1Updates;
		return $result;
	}

	public function getBaseBlockPosition() : BlockPosition{ return $this->baseBlockPosition; }

	/** @return UpdateSubChunkBlocksPacketEntry[] */
	public function getLayer0Updates() : array{ return $this->layer0Updates; }

	/** @return UpdateSubChunkBlocksPacketEntry[] */
	public function getLayer1Updates() : array{ return $this->layer1Updates; }

	protected function decodePayload(ByteBufferReader $in, int $protocolId) : void{
		$this->baseBlockPosition = CommonTypes::getBlockPosition($in, $protocolId >= ProtocolInfo::PROTOCOL_1_26_10);
		$this->layer0Updates = [];
		for($i = 0, $count = VarInt::readUnsignedInt($in); $i < $count; ++$i){
			$this->layer0Updates[] = UpdateSubChunkBlocksPacketEntry::read($in, $protocolId);
		}
		$this->layer1Updates = [];
		for($i = 0, $count = VarInt::readUnsignedInt($in); $i < $count; ++$i){
			$this->layer1Updates[] = UpdateSubChunkBlocksPacketEntry::read($in, $protocolId);
		}
	}

	protected function encodePayload(ByteBufferWriter $out, int $protocolId) : void{
		CommonTypes::putBlockPosition($out, $this->baseBlockPosition, $protocolId >= ProtocolInfo::PROTOCOL_1_26_10);
		VarInt::writeUnsignedInt($out, count($this->layer0Updates));
		foreach($this->layer0Updates as $update){
			$update->write($out, $protocolId);
		}
		VarInt::writeUnsignedInt($out, count($this->layer1Updates));
		foreach($this->layer1Updates as $update){
			$update->write($out, $protocolId);
		}
	}

	public function handle(PacketHandlerInterface $handler) : bool{
		return $handler->handleUpdateSubChunkBlocks($this);
	}
}
