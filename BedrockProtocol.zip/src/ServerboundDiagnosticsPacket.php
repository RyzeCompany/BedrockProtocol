<?php

/*
 * This file is part of BedrockProtocol.
 * Copyright (C) 2014-2022 PocketMine Team <https://github.com/pmmp/BedrockProtocol>
 *
 * BedrockProtocol is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

declare(strict_types=1);

namespace pocketmine\network\mcpe\protocol;

use pmmp\encoding\ByteBufferReader;
use pmmp\encoding\ByteBufferWriter;
use pmmp\encoding\LE;
use pmmp\encoding\VarInt;
use pocketmine\network\mcpe\protocol\types\EntityDiagnosticTimingInfo;
use pocketmine\network\mcpe\protocol\types\MemoryCategoryCounter;
use pocketmine\network\mcpe\protocol\types\SystemCategory;
use pocketmine\network\mcpe\protocol\types\SystemDiagnosticTimingInfo;
use pocketmine\network\mcpe\protocol\types\WhiskerScopeDataSummary;
use function count;

class ServerboundDiagnosticsPacket extends DataPacket implements ServerboundPacket{
	public const NETWORK_ID = ProtocolInfo::SERVERBOUND_DIAGNOSTICS_PACKET;

	private float $avgFps;
	private float $avgServerSimTickTimeMS;
	private float $avgClientSimTickTimeMS;
	private float $avgBeginFrameTimeMS;
	private float $avgInputTimeMS;
	private float $avgRenderTimeMS;
	private float $avgEndFrameTimeMS;
	private float $avgRemainderTimePercent;
	private float $avgUnaccountedTimePercent;
	/**
	 * @var MemoryCategoryCounter[]
	 * @phpstan-var list<MemoryCategoryCounter>
	 */
	private array $memoryCategoryValues = [];
	/**
	 * @var EntityDiagnosticTimingInfo[]
	 * @phpstan-var list<EntityDiagnosticTimingInfo>
	 */
	private array $entityDiagnostics = [];
	/**
	 * @var SystemDiagnosticTimingInfo[]
	 * @phpstan-var list<SystemDiagnosticTimingInfo>
	 */
	private array $systemDiagnostics = [];
	/**
	 * @var SystemCategory[]
	 * @phpstan-var list<SystemCategory>
	 */
	private array $systemCategories = [];
	/**
	 * @var WhiskerScopeDataSummary[]
	 * @phpstan-var list<WhiskerScopeDataSummary>
	 */
	private array $whiskerScopes = [];

	/**
	 * @generate-create-func
	 * @param MemoryCategoryCounter[]      $memoryCategoryValues
	 * @param EntityDiagnosticTimingInfo[] $entityDiagnostics
	 * @param SystemDiagnosticTimingInfo[] $systemDiagnostics
	 * @param WhiskerScopeDataSummary[]    $whiskerScopes
	 * @param SystemCategory[]             $systemCategories
	 * @phpstan-param list<MemoryCategoryCounter>      $memoryCategoryValues
	 * @phpstan-param list<EntityDiagnosticTimingInfo> $entityDiagnostics
	 * @phpstan-param list<SystemDiagnosticTimingInfo> $systemDiagnostics
	 * @phpstan-param list<WhiskerScopeDataSummary>    $whiskerScopes
	 * @phpstan-param list<SystemCategory>             $systemCategories
	 */
	public static function create(
		float $avgFps,
		float $avgServerSimTickTimeMS,
		float $avgClientSimTickTimeMS,
		float $avgBeginFrameTimeMS,
		float $avgInputTimeMS,
		float $avgRenderTimeMS,
		float $avgEndFrameTimeMS,
		float $avgRemainderTimePercent,
		float $avgUnaccountedTimePercent,
		array $memoryCategoryValues,
		array $entityDiagnostics,
		array $systemDiagnostics,
		array $whiskerScopes,
		array $systemCategories = [],
	) : self{
		$result = new self;
		$result->avgFps = $avgFps;
		$result->avgServerSimTickTimeMS = $avgServerSimTickTimeMS;
		$result->avgClientSimTickTimeMS = $avgClientSimTickTimeMS;
		$result->avgBeginFrameTimeMS = $avgBeginFrameTimeMS;
		$result->avgInputTimeMS = $avgInputTimeMS;
		$result->avgRenderTimeMS = $avgRenderTimeMS;
		$result->avgEndFrameTimeMS = $avgEndFrameTimeMS;
		$result->avgRemainderTimePercent = $avgRemainderTimePercent;
		$result->avgUnaccountedTimePercent = $avgUnaccountedTimePercent;
		$result->memoryCategoryValues = $memoryCategoryValues;
		$result->entityDiagnostics = $entityDiagnostics;
		$result->systemDiagnostics = $systemDiagnostics;
		$result->whiskerScopes = $whiskerScopes;
		$result->systemCategories = $systemCategories;
		return $result;
	}

	public function getAvgFps() : float{ return $this->avgFps; }

	public function getAvgServerSimTickTimeMS() : float{ return $this->avgServerSimTickTimeMS; }

	public function getAvgClientSimTickTimeMS() : float{ return $this->avgClientSimTickTimeMS; }

	public function getAvgBeginFrameTimeMS() : float{ return $this->avgBeginFrameTimeMS; }

	public function getAvgInputTimeMS() : float{ return $this->avgInputTimeMS; }

	public function getAvgRenderTimeMS() : float{ return $this->avgRenderTimeMS; }

	public function getAvgEndFrameTimeMS() : float{ return $this->avgEndFrameTimeMS; }

	public function getAvgRemainderTimePercent() : float{ return $this->avgRemainderTimePercent; }

	public function getAvgUnaccountedTimePercent() : float{ return $this->avgUnaccountedTimePercent; }

	/**
	 * @return MemoryCategoryCounter[]
	 * @phpstan-return list<MemoryCategoryCounter>
	 */
	public function getMemoryCategoryValues() : array{ return $this->memoryCategoryValues; }

	/**
	 * @return EntityDiagnosticTimingInfo[]
	 * @phpstan-return list<EntityDiagnosticTimingInfo>
	 */
	public function getEntityDiagnostics() : array{ return $this->entityDiagnostics; }

	/**
	 * @return SystemDiagnosticTimingInfo[]
	 * @phpstan-return list<SystemDiagnosticTimingInfo>
	 */
	public function getSystemDiagnostics() : array{ return $this->systemDiagnostics; }

	/**
	 * @return SystemCategory[]
	 * @phpstan-return list<SystemCategory>
	 */
	public function getSystemCategories() : array{ return $this->systemCategories; }

	/**
	 * @return WhiskerScopeDataSummary[]
	 * @phpstan-return list<WhiskerScopeDataSummary>
	 */
	public function getWhiskerScopes() : array{ return $this->whiskerScopes; }

	protected function decodePayload(ByteBufferReader $in, int $protocolId) : void{
		$this->avgFps = LE::readFloat($in);
		$this->avgServerSimTickTimeMS = LE::readFloat($in);
		$this->avgClientSimTickTimeMS = LE::readFloat($in);
		$this->avgBeginFrameTimeMS = LE::readFloat($in);
		$this->avgInputTimeMS = LE::readFloat($in);
		$this->avgRenderTimeMS = LE::readFloat($in);
		$this->avgEndFrameTimeMS = LE::readFloat($in);
		$this->avgRemainderTimePercent = LE::readFloat($in);
		$this->avgUnaccountedTimePercent = LE::readFloat($in);

		if($protocolId >= ProtocolInfo::PROTOCOL_1_26_0){
			$this->memoryCategoryValues = [];
			for($i = 0, $count = VarInt::readUnsignedInt($in); $i < $count; $i++){
				$this->memoryCategoryValues[] = MemoryCategoryCounter::read($in);
			}

			if($protocolId >= ProtocolInfo::PROTOCOL_1_26_20){
				$this->entityDiagnostics = [];
				for($i = 0, $count = VarInt::readUnsignedInt($in); $i < $count; $i++){
					$this->entityDiagnostics[] = EntityDiagnosticTimingInfo::read($in, $protocolId);
				}

				$this->systemDiagnostics = [];
				for($i = 0, $count = VarInt::readUnsignedInt($in); $i < $count; $i++){
					$this->systemDiagnostics[] = SystemDiagnosticTimingInfo::read($in);
				}
				if($protocolId >= ProtocolInfo::PROTOCOL_1_26_40){
					$this->systemCategories = [];
					for($i = 0, $count = VarInt::readUnsignedInt($in); $i < $count; $i++){
						$this->systemCategories[] = SystemCategory::read($in);
					}
				}

				if($protocolId >= ProtocolInfo::PROTOCOL_1_26_30){
					$this->whiskerScopes = [];
					for($i = 0, $count = VarInt::readUnsignedInt($in); $i < $count; $i++){
						$this->whiskerScopes[] = WhiskerScopeDataSummary::read($in);
					}
				}
			}
		}
	}

	protected function encodePayload(ByteBufferWriter $out, int $protocolId) : void{
		LE::writeFloat($out, $this->avgFps);
		LE::writeFloat($out, $this->avgServerSimTickTimeMS);
		LE::writeFloat($out, $this->avgClientSimTickTimeMS);
		LE::writeFloat($out, $this->avgBeginFrameTimeMS);
		LE::writeFloat($out, $this->avgInputTimeMS);
		LE::writeFloat($out, $this->avgRenderTimeMS);
		LE::writeFloat($out, $this->avgEndFrameTimeMS);
		LE::writeFloat($out, $this->avgRemainderTimePercent);
		LE::writeFloat($out, $this->avgUnaccountedTimePercent);

		if($protocolId >= ProtocolInfo::PROTOCOL_1_26_0){
			VarInt::writeUnsignedInt($out, count($this->memoryCategoryValues));
			foreach($this->memoryCategoryValues as $value){
				$value->write($out);
			}

			if($protocolId >= ProtocolInfo::PROTOCOL_1_26_20){
				VarInt::writeUnsignedInt($out, count($this->entityDiagnostics));
				foreach($this->entityDiagnostics as $value){
					$value->write($out, $protocolId);
				}

				VarInt::writeUnsignedInt($out, count($this->systemDiagnostics));
				foreach($this->systemDiagnostics as $value){
					$value->write($out);
				}
				if($protocolId >= ProtocolInfo::PROTOCOL_1_26_40){
					VarInt::writeUnsignedInt($out, count($this->systemCategories));
					foreach($this->systemCategories as $value){
						$value->write($out);
					}
				}

				if($protocolId >= ProtocolInfo::PROTOCOL_1_26_30){
					VarInt::writeUnsignedInt($out, count($this->whiskerScopes));
					foreach($this->whiskerScopes as $value){
						$value->write($out);
					}
				}
			}
		}
	}

	public function handle(PacketHandlerInterface $handler) : bool{
		return $handler->handleServerboundDiagnostics($this);
	}
}
